define({
  "widgets": {
    "ShareDialog": {
      "title": "Megosztás",
      "heading": "A térkép megosztása",
      "url": "Térkép hivatkozása",
      "embed": "Térkép beágyazása",
      "extent": "Aktuális térképkiterjedés megosztása",
      "size": "Méret (szélesség/magasság):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail"
    }
  }
});