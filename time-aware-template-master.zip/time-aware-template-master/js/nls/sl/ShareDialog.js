define({
  "widgets": {
    "ShareDialog": {
      "title": "Deli",
      "heading": "Deli to karto",
      "url": "Povezava do karte",
      "embed": "Vdelana karta",
      "extent": "Deli trenutni obseg karte",
      "size": "Velikost (širina/višina):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-pošta"
    }
  }
});