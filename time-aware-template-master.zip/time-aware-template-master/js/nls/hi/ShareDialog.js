define({
  "widgets": {
    "ShareDialog": {
      "title": "साझा करें",
      "heading": "इस मानचित्र को साझा करें",
      "url": "मानचित्र लिंक",
      "embed": "मानचित्र संबद्ध करें",
      "extent": "मानचित्र की वर्तमान सीमा साझा करें",
      "size": "आकार (चौड़ाई/ऊंचाई):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "ईमेल"
    }
  }
});