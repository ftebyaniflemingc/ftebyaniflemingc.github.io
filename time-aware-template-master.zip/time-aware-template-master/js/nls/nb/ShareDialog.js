define({
  "widgets": {
    "ShareDialog": {
      "title": "Dele",
      "heading": "Del dette kartet",
      "url": "Kartkobling",
      "embed": "Bygg inn kart",
      "extent": "Del gjeldende kartutstrekning",
      "size": "Størrelse (bredde/høyde):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-post"
    }
  }
});