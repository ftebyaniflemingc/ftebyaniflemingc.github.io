define({
  "widgets": {
    "ShareDialog": {
      "title": "Compartilhar o",
      "heading": "Compartilhar este mapa",
      "url": "Link do Mapa",
      "embed": "Mapa Embutido",
      "extent": "Compartilhar extensão de mapa atual",
      "size": "Tamanho (largura/altura):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail"
    }
  }
});