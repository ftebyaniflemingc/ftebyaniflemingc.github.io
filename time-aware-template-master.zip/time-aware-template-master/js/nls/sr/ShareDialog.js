define({
  "widgets": {
    "ShareDialog": {
      "title": "Podeli",
      "heading": "Podeli ovu mapu",
      "url": "Link ka mapi",
      "embed": "Ugradi mapu",
      "extent": "Podeli trenutni obuhvat mape",
      "size": "Veličina (širina/visina):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-pošta"
    }
  }
});